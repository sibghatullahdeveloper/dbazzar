<?php

namespace App\Services;

use App\User;
use Carbon\Carbon;
use App\Model\ProductCategories;
use Illuminate\Support\Str;


class ProductCategoryService
{

    public static function ProductCategoryList(){

        return ProductCategories::get();
    }

    public static function SaveProductCategory($request, $entity_id){

        $p_cat = new ProductCategories();

        if(isset($request['id'])){

        $p_cat->where('id',$request['id'])
                ->update([
                            'name' => $request['name'],
                            'status' => $request['status'],
                            'start_date_time' => $request['start_time'],
                            'end_date_time' => $request['end_time'],
                            'entity_id' => $entity_id,
                            'updated_at' =>Carbon::now()
                          ]);
        }else{
                $p_cat->name=$request['name'];
                $p_cat->start_date_time=$request['start_time'];
                $p_cat->end_date_time=$request['end_time'];
                $p_cat->status=$request['status'];
                $p_cat->entity_id=$entity_id;
                $p_cat->uuid=Str::uuid();
                $p_cat->save();
        }

        return true;
    }

    public function EditProductCategory($uuid){
        
        $p_cat = ProductCategories::where('uuid',$uuid)->first();
        
        return  $p_cat;
    }

    public function DeleteProductCategory($id){

        $p_cat = ProductCategories::find($id);
        $p_cat->delete();
        
        return  true;
    }

    public function FindCategoriesById($ids){

        $lists = json_decode($ids);

        $i = 0;
        foreach($lists as $list){

            $output[$i] = ProductCategories::where('id',$list)->first();
            $output[$i++];

        }
        
        return  $output;
    }

}