<?php

namespace App\Services;

use App\User;
use Carbon\Carbon;
use App\Model\FoodItems;
use Illuminate\Support\Str;


class FoodItemsService
{

    public static function FoodItemsList(){

        return FoodItems::get();
    }

    public static function SaveFoodItems($request){

        $fooditems = new FoodItems();

        $addons_ids = json_encode($request->addons_ids);
        $p_cat_ids = json_encode($request->p_cat_ids);

        if ($request->file('image')) {

            $fooditems->image = $request->file('image');
            $imageName = time().'.'.$fooditems->image->extension();
            $fooditems->image = $request->image->store('/foodItems_images', 'public');

            if(isset($request['id'])){

                $fooditems->where('id',$request['id'])
                        ->update([
                                    'name' => $request['name'],
                                    'status' => $request['status'],
                                    'description' => $request['description'],
                                    'price' => $request['price'],
                                    'discount' => $request['discount'],
                                    'image' => $fooditems->image,
                                    'addons_id' => $addons_ids,
                                    'p_cat_id' => $p_cat_ids,
                                    'updated_at' =>Carbon::now()
                                  ]);
            }else{
                $fooditems->name=$request['name'];
                $fooditems->status=$request['status'];
                $fooditems->description=$request['description'];
                $fooditems->price=$request['price'];
                $fooditems->addons_id=$addons_ids;
                $fooditems->discount=$request['discount'];
                $fooditems->p_cat_id=$p_cat_ids;
                $fooditems->uuid=Str::uuid();
                $fooditems->save();
            }
        }
        else{
            
            if(isset($request['id'])){

                $fooditems->where('id',$request['id'])
                        ->update([
                                    'name' => $request['name'],
                                    'status' => $request['status'],
                                    'description' => $request['description'],
                                    'price' => $request['price'],
                                    'addons_id' => $addons_ids,
                                    'discount' => $request['discount'],
                                    'p_cat_id' => $p_cat_ids,
                                    'updated_at' =>Carbon::now()
                                  ]);
            }else{
                $fooditems->name=$request['name'];
                $fooditems->status=$request['status'];
                $fooditems->description=$request['description'];
                $fooditems->price=$request['price'];
                $fooditems->addons_id=$addons_ids;
                $fooditems->discount=$request['discount'];
                $fooditems->p_cat_id=$p_cat_ids;
                $fooditems->uuid=Str::uuid();
                $fooditems->save();
            }
        }


        return true;
    }

    public function EditFoodItems($uuid){
        
        $fooditems = FoodItems::where('uuid',$uuid)->first();
        
        return  $fooditems;
    }

    public function DeleteFoodItems($id){

        $fooditems = FoodItems::find($id);
        $fooditems->delete();
        
        return  true;
    }

}